/**
 * useOrdersMetrics Hook
 * Aggregates PURCHASE-order data for reports and dashboards.
 *
 * Every money figure in here is procurement spend — what the restaurant PAYS
 * its vendors, read from `procurement_orders` via `ordersApi`. It is not sales
 * revenue and must never be labelled as such: sales revenue lives in
 * `pos_checks` and is not fetched by this hook.
 */

import { useState, useEffect, useCallback, useMemo } from 'react'
import { useAuth } from '../contexts/AuthContext'
import { ordersApi } from '../services/api'
import type { OrderStatus } from '../services/api/types'
import { useOrdersSubscription } from '../contexts/RealtimeContext'

interface StoredOrder {
  id: string
  wineId: string
  wineName: string
  quantity: number
  /**
   * The AGREED price and the order's total, as the route sends them
   * (`finalPrice` / `totalCost`). NULL means the payload carried no figure —
   * never 0. Until 2026-09-05 this hook read `unitPrice` / `totalPrice`, names
   * `OrderResponseDto` has never sent, and defaulted both to 0: every spend
   * figure on /reports and the dashboard's top-wines table was therefore
   * summed from zeroes and read as "nothing was spent". Nulls are now SKIPPED
   * by the sums and COUNTED in `unpricedOrders`.
   */
  unitPrice: number | null
  totalPrice: number | null
  providerId: string
  providerName: string
  status: 'pending' | 'approved' | 'ordered' | 'delivered' | 'cancelled'
  createdAt: string
  approvedAt?: string
  deliveredAt?: string
  cancelledAt?: string
  wineType?: 'red' | 'white' | 'sparkling' | 'rose' | 'dessert'
}

interface OrderMetrics {
  // Overall metrics
  totalOrders: number
  totalOrderValue: number
  totalBottlesOrdered: number
  avgOrderValue: number
  /**
   * Orders in the window whose value the route did not carry. They are not in
   * `totalOrderValue`, and reading that figure without this one reads an
   * absence as a zero.
   */
  unpricedOrders: number
  
  // Status breakdown
  pendingOrders: number
  approvedOrders: number
  deliveredOrders: number
  cancelledOrders: number
  
  // Time-based metrics
  ordersThisMonth: number
  ordersLastMonth: number
  /** Money paid to vendors this calendar month (procurement spend, not revenue). */
  spendThisMonth: number
  /** Money paid to vendors last calendar month (procurement spend, not revenue). */
  spendLastMonth: number
  /** Month-over-month change in vendor SPEND. Positive means costs rose. */
  monthOverMonthGrowth: number
  
  // Wine type distribution
  ordersByWineType: {
    red: number
    white: number
    sparkling: number
    rose: number
    dessert: number
  }
  
  // Top performers
  topOrderedWines: Array<{
    wineId: string
    wineName: string
    quantity: number
    totalValue: number
  }>
  
  // Provider metrics
  ordersByProvider: Array<{
    providerId: string
    providerName: string
    orderCount: number
    totalValue: number
  }>
  
  // Daily data for charts
  dailyOrderData: Array<{
    date: string
    orders: number
    bottles: number
    /** Money paid to vendors that day, summed from `totalPrice`. Not revenue. */
    spend: number
  }>
}

/** Sum only the rows whose value the route actually carried. */
const sumKnown = (rows: StoredOrder[]): number =>
  rows.reduce((sum, o) => (o.totalPrice == null ? sum : sum + o.totalPrice), 0)

/** How many of those rows carried no value at all. */
const countUnpriced = (rows: StoredOrder[]): number =>
  rows.reduce((n, o) => (o.totalPrice == null ? n + 1 : n), 0)

const mapOrderStatus = (status?: string): StoredOrder['status'] => {
  const lower = (status || '').toLowerCase().replace(/-/g, '_')
  switch (lower) {
    case 'pending':
    case 'pending_approval':
    case 'approval_needed':
    case 'draft':
    case 'negotiating':
      return 'pending'
    case 'approved':
    case 'confirmed':
    case 'ordered':
    case 'in_transit':
    case 'intransit':
      return 'approved'
    case 'delivered':
    case 'completed':
    case 'verified':
      return 'delivered'
    case 'cancelled':
    case 'canceled':
    case 'rejected':
    case 'failed':
      return 'cancelled'
    default:
      return 'pending'
  }
}

export function useOrdersMetrics() {
  const [orders, setOrders] = useState<StoredOrder[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { activeRestaurantId, isAuthenticated } = useAuth()

  const fetchOrders = useCallback(async () => {
    if (!activeRestaurantId) {
      setIsLoading(false)
      return
    }
    setIsLoading(true)
    try {
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - 90)
      const [historyResult, approvedOrders] = await Promise.all([
        ordersApi.getOrderHistory(
          {
            limit: 100,
            dateFrom: startDate.toISOString().split('T')[0],
          },
          activeRestaurantId
        ),
        ordersApi.getOrders({ status: 'approved' as OrderStatus }, activeRestaurantId).catch(() => []),
      ])

      const combined = [
        ...historyResult.data,
        ...approvedOrders,
      ]

      const unique = new Map<string, any>()
      combined.forEach((order) => {
        if (order?.id && !unique.has(order.id)) {
          unique.set(order.id, order)
        }
      })

      const mapped: StoredOrder[] = Array.from(unique.values()).map((order) => ({
        id: order.id,
        wineId: order.inventoryId || '',
        wineName: order.wineName || 'Unknown Wine',
        quantity: order.quantity,
        // `finalPrice` / `totalCost` are the route's own names. No derivation
        // from the pair: `finalPrice` is stated per `priceUom`, so multiplying
        // it by the quantity is the per-bottle assumption ADR 0119 exists to
        // end — a case price times sixty bottles is twelve times the truth.
        unitPrice: order.finalPrice ?? null,
        totalPrice: order.totalCost ?? null,
        providerId: order.providerId || '',
        // The route sends no vendor name, only `providerId`.
        providerName: 'Not named by this route',
        status: mapOrderStatus(order.status),
        createdAt: order.requestedAt || '',
        approvedAt: order.approvedAt,
        deliveredAt: order.deliveredAt,
        cancelledAt: undefined,
      }))
      setOrders(mapped)
    } catch (error) {
      setOrders([])
    } finally {
      setIsLoading(false)
    }
  }, [activeRestaurantId])

  useEffect(() => {
    if (isAuthenticated) {
      fetchOrders()
    }
  }, [fetchOrders, isAuthenticated])

  useOrdersSubscription(() => {
    if (!activeRestaurantId || !isAuthenticated) return
    fetchOrders()
  })

  const addOrder = useCallback((_order: Omit<StoredOrder, 'id' | 'createdAt'>) => {
    fetchOrders()
    return null
  }, [fetchOrders])

  const updateOrderStatus = useCallback((_orderId: string, _status: StoredOrder['status']) => {
    fetchOrders()
  }, [fetchOrders])

  // Calculate metrics
  const metrics: OrderMetrics = useMemo(() => {
    const now = new Date()
    const thisMonth = now.getMonth()
    const lastMonth = thisMonth === 0 ? 11 : thisMonth - 1
    const thisYear = now.getFullYear()
    const lastMonthYear = thisMonth === 0 ? thisYear - 1 : thisYear

    // Filter by time period
    const thisMonthOrders = orders.filter(o => {
      const date = new Date(o.createdAt)
      return date.getMonth() === thisMonth && date.getFullYear() === thisYear
    })
    
    const lastMonthOrders = orders.filter(o => {
      const date = new Date(o.createdAt)
      return date.getMonth() === lastMonth && date.getFullYear() === lastMonthYear
    })

    // Calculate base metrics
    const totalOrders = orders.length
    const totalOrderValue = sumKnown(orders)
    const unpricedOrders = countUnpriced(orders)
    const totalBottlesOrdered = orders.reduce((sum, o) => sum + o.quantity, 0)
    // Divided by the PRICED orders: an unpriced one is missing from the
    // numerator, so counting it in the denominator halves the average.
    const pricedOrders = totalOrders - unpricedOrders
    const avgOrderValue = pricedOrders > 0 ? totalOrderValue / pricedOrders : 0

    // Status counts
    const pendingOrders = orders.filter(o => o.status === 'pending').length
    const approvedOrders = orders.filter(o => o.status === 'approved').length
    const deliveredOrders = orders.filter(o => o.status === 'delivered').length
    const cancelledOrders = orders.filter(o => o.status === 'cancelled').length

    // Time-based metrics
    const ordersThisMonth = thisMonthOrders.length
    const ordersLastMonth = lastMonthOrders.length
    const spendThisMonth = sumKnown(thisMonthOrders)
    const spendLastMonth = sumKnown(lastMonthOrders)
    const monthOverMonthGrowth = spendLastMonth > 0
      ? ((spendThisMonth - spendLastMonth) / spendLastMonth) * 100
      : 0

    // Wine type distribution
    const ordersByWineType = {
      red: orders.filter(o => o.wineType === 'red').reduce((sum, o) => sum + o.quantity, 0),
      white: orders.filter(o => o.wineType === 'white').reduce((sum, o) => sum + o.quantity, 0),
      sparkling: orders.filter(o => o.wineType === 'sparkling').reduce((sum, o) => sum + o.quantity, 0),
      rose: orders.filter(o => o.wineType === 'rose').reduce((sum, o) => sum + o.quantity, 0),
      dessert: orders.filter(o => o.wineType === 'dessert').reduce((sum, o) => sum + o.quantity, 0),
    }

    // Top ordered wines
    const wineAggregation = orders.reduce((acc, order) => {
      if (!acc[order.wineId]) {
        acc[order.wineId] = {
          wineId: order.wineId,
          wineName: order.wineName,
          quantity: 0,
          totalValue: 0,
        }
      }
      acc[order.wineId].quantity += order.quantity
      acc[order.wineId].totalValue += order.totalPrice ?? 0
      return acc
    }, {} as Record<string, { wineId: string; wineName: string; quantity: number; totalValue: number }>)

    const topOrderedWines = Object.values(wineAggregation)
      .sort((a, b) => b.totalValue - a.totalValue)
      .slice(0, 10)

    // Provider metrics
    const providerAggregation = orders.reduce((acc, order) => {
      if (!acc[order.providerId]) {
        acc[order.providerId] = {
          providerId: order.providerId,
          providerName: order.providerName,
          orderCount: 0,
          totalValue: 0,
        }
      }
      acc[order.providerId].orderCount += 1
      acc[order.providerId].totalValue += order.totalPrice ?? 0
      return acc
    }, {} as Record<string, { providerId: string; providerName: string; orderCount: number; totalValue: number }>)

    const ordersByProvider = Object.values(providerAggregation)
      .sort((a, b) => b.totalValue - a.totalValue)

    // Daily data for last 30 days
    const dailyOrderData: OrderMetrics['dailyOrderData'] = []
    for (let i = 29; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      const dateStr = date.toISOString().split('T')[0]
      
      const dayOrders = orders.filter(o => 
        o.createdAt.startsWith(dateStr)
      )
      
      dailyOrderData.push({
        date: dateStr,
        orders: dayOrders.length,
        bottles: dayOrders.reduce((sum, o) => sum + o.quantity, 0),
        spend: sumKnown(dayOrders),
      })
    }

    return {
      totalOrders,
      totalOrderValue,
      totalBottlesOrdered,
      avgOrderValue,
      unpricedOrders,
      pendingOrders,
      approvedOrders,
      deliveredOrders,
      cancelledOrders,
      ordersThisMonth,
      ordersLastMonth,
      spendThisMonth,
      spendLastMonth,
      monthOverMonthGrowth,
      ordersByWineType,
      topOrderedWines,
      ordersByProvider,
      dailyOrderData,
    }
  }, [orders])

  return {
    orders,
    metrics,
    isLoading,
    addOrder,
    updateOrderStatus,
    refreshOrders: () => fetchOrders(),
  }
}

export type { StoredOrder, OrderMetrics }
